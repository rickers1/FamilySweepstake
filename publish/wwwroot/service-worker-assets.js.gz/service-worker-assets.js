self.assetsManifest = {
  "version": "YVvUYFqO",
  "assets": [
    {
      "hash": "sha256-LYkXtdz4vi5vXmNqTm7rXR8RNenk5jtch4ULcWJFhKg=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-RCP1u+n2DiNin+A6Edw6xsfWpI03aYyzU8pijagzeGQ=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-3Z7kKpQRMX82Ssav4HofwZznPVFgOXuZ2O8McYyP4Zg=",
      "url": "_content/MudBlazor/MudBlazor.min.js.map"
    },
    {
      "hash": "sha256-NoipRAkBkX3OQHJqPP/PIPRBZTOsIUJvlU81rnyDvR8=",
      "url": "_framework/FamilySweepstake.i2fq1el32r.wasm"
    },
    {
      "hash": "sha256-k0a5+tm05MdNQ+opFKIqd9FZ2nTCVzZgVX+fVQ0LMXA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.buduh5c45m.wasm"
    },
    {
      "hash": "sha256-xPf4uC9P9+0sJv5dEILUxovpu5AkQ2oaIi9VBxV5+PI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.k8x6a8y224.wasm"
    },
    {
      "hash": "sha256-esIAcXWf13scNF2AbUZadjwB95ECu9FgJWr3smRs3co=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ubly6f8lvn.wasm"
    },
    {
      "hash": "sha256-FXpqqyqHqnNBtKk5xiBE290814y1WJEZEGBJA7rR/XY=",
      "url": "_framework/Microsoft.AspNetCore.Components.tyvd31p2wx.wasm"
    },
    {
      "hash": "sha256-+I/WglQ6m2asT3Pam54/OLMlwi5DB6HWbebWPOo1Oo4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.cbncbp4ldi.wasm"
    },
    {
      "hash": "sha256-NjAIjIQlITJK5e/1cNjeMLBSuW2yXbc3mfYPnlQU0WU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ixktlrimdt.wasm"
    },
    {
      "hash": "sha256-gUyXORgwqoEI/hD+5DNKBPy1fHCsRf9JHgA2yyHBDhI=",
      "url": "_framework/Microsoft.Extensions.Configuration.lr61ofcgfm.wasm"
    },
    {
      "hash": "sha256-1sobd0+jKGZXPSYvyHoXAtAXOKqDKb3Q4kuski/0Ukw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.absadohaxa.wasm"
    },
    {
      "hash": "sha256-Uf2OoF4AD/nB8bEP9+Vtasx3otZscbwOarFh3Uu7bQI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b9mcrj62ry.wasm"
    },
    {
      "hash": "sha256-ZbTnZVFsW5YBhb5oMBSOB+sbuloQvsjuUYZ8boT2RuA=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.xt73qsqilp.wasm"
    },
    {
      "hash": "sha256-L2P/tLhZ6FSR1KG27vIE/jer8JBjOAPRMf7D9eFEUNs=",
      "url": "_framework/Microsoft.Extensions.Localization.xcslyy3nju.wasm"
    },
    {
      "hash": "sha256-OdFig2kvA5Qr1N1HUvmzU2R4K/QGRZlN59kVqfDjuhg=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.pcnk6eea8v.wasm"
    },
    {
      "hash": "sha256-mbNEmfqRHcXa1eXIsnSfoKUSC1/ZdphrzRhl3iZFUjU=",
      "url": "_framework/Microsoft.Extensions.Logging.vqiumbbk2y.wasm"
    },
    {
      "hash": "sha256-/Tigjnen6a8njgGooGLwvpW/FpspaBVuuEjycsCD1p8=",
      "url": "_framework/Microsoft.Extensions.Options.99vr637tk6.wasm"
    },
    {
      "hash": "sha256-ymLJ18O0TWi69zlDhVo+NpMt34Z3v1+9qEyGdf3sJFI=",
      "url": "_framework/Microsoft.Extensions.Primitives.yxjt7vtatl.wasm"
    },
    {
      "hash": "sha256-Xcxd+z/8v1MjYI/6IsNgJ46ifV38aKmiGyz4RR+L0ms=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ydn64ly88.wasm"
    },
    {
      "hash": "sha256-z+WJgToURJEP7oFhOgd9QC/aiMhsdRRPn4hItetb2QE=",
      "url": "_framework/Microsoft.JSInterop.f0wnw1ycrt.wasm"
    },
    {
      "hash": "sha256-6aVyBFRwA5c7/zD8+rzMxjG9dVfqVwds26a5OoAv0jw=",
      "url": "_framework/MudBlazor.1ufvkwzww8.wasm"
    },
    {
      "hash": "sha256-qPdgcuLFp0bjUFIlbkVcMNOvI7l+dVnmRxKPqUFdvY0=",
      "url": "_framework/System.Collections.4tov94seas.wasm"
    },
    {
      "hash": "sha256-H06Hl8VzKf/cP6ybOUQVJi/lnlL02IiilzNGD17xmsQ=",
      "url": "_framework/System.Collections.Concurrent.tdfw4qrfm5.wasm"
    },
    {
      "hash": "sha256-88VrTxr9RVtWHV4bCGyr643X4kcCkmKPhIo/7yN3rX0=",
      "url": "_framework/System.Collections.Immutable.zsew3cyknd.wasm"
    },
    {
      "hash": "sha256-ptToh764Hu83hbH8gmxGk9FrMlLUh7Bo05fPYCisg9s=",
      "url": "_framework/System.ComponentModel.Annotations.ix7q2ye145.wasm"
    },
    {
      "hash": "sha256-u6eyOmgoMHophXATIgej9B8x3toeUO8w6V5zSlE1g1E=",
      "url": "_framework/System.ComponentModel.Primitives.fz4qc4rxl4.wasm"
    },
    {
      "hash": "sha256-J1lLLtC4XYSVr/33KkpAPwfdmdFAm0Tg4PkXsl7XfLw=",
      "url": "_framework/System.ComponentModel.llxzyckf9y.wasm"
    },
    {
      "hash": "sha256-NoT4iWX6x8RkAdKhR8uUPIJVJ7PL+adcC21RhTp+I1Y=",
      "url": "_framework/System.Console.avt4g12ln8.wasm"
    },
    {
      "hash": "sha256-e4OvNTqQGMEqyEQPtgREWUJgdltuDI1YY7Dt2Q5czZY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.7dyylnf3b0.wasm"
    },
    {
      "hash": "sha256-xtdOKQZpNum4/1xVdvHxEcE6rSiRpnADTbN3z/ut9DA=",
      "url": "_framework/System.IO.Pipelines.uznrqn6wwr.wasm"
    },
    {
      "hash": "sha256-qj6/x7klcysYAMyAbKMJSamAFNMyMhnoy6Qi/1qRHuU=",
      "url": "_framework/System.Linq.Expressions.61kl2h0rno.wasm"
    },
    {
      "hash": "sha256-NoUWfuKeN8X/ub5x1rZG0OQ97D1DlMm1ziFiUQgTZ6k=",
      "url": "_framework/System.Linq.e7gndv0bti.wasm"
    },
    {
      "hash": "sha256-2yaju74+5AK99ukgivZY/fgBnQAEbZ7xQ6ULbDhq0L8=",
      "url": "_framework/System.Memory.dmchb5mcb4.wasm"
    },
    {
      "hash": "sha256-g2FQ5Nm5l/99flj54WOYEF76UcTRxeYEVQsAIAfyyTs=",
      "url": "_framework/System.Net.Http.Json.zwy71hftl2.wasm"
    },
    {
      "hash": "sha256-N9Sh1JelQIoJV6mHt6pehNHXObwrbU9hGhpva7Tfibw=",
      "url": "_framework/System.Net.Http.rr930oqqi9.wasm"
    },
    {
      "hash": "sha256-VQhHwNdLAM128ioyKptROauyqsp5j389mcIX3oXbZT4=",
      "url": "_framework/System.Net.Primitives.lomeqtjib9.wasm"
    },
    {
      "hash": "sha256-nb2UJJP/Ts8XZg86aNvSVh1AcwnAjFu+fLP/E7OB0Xc=",
      "url": "_framework/System.Private.CoreLib.pdvzg53rqp.wasm"
    },
    {
      "hash": "sha256-tcOuRsGkNinprQjMrWyI2oKHDCLRVcTVB/gA0bXYB3w=",
      "url": "_framework/System.Private.Uri.vr6w2cyxdp.wasm"
    },
    {
      "hash": "sha256-8dAeYP1ooz071MHVhHIVl6ljhupDIHU5h6aDO7fhLBI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.xs6yu76bks.wasm"
    },
    {
      "hash": "sha256-mFgg+qcpzec/UPCag2xkzpzp5RQwaPGVCXYpSyyECBw=",
      "url": "_framework/System.Runtime.InteropServices.kdrgmxrrq0.wasm"
    },
    {
      "hash": "sha256-IjVRIkqcaTT1BihgRzA5pyBcedsxWuKIsitEVEBXOmA=",
      "url": "_framework/System.Runtime.m2c7qmy87b.wasm"
    },
    {
      "hash": "sha256-EtCAv8n8nbXWUJNH16d5QxTfbrvBzSNzfiMZBRA5N64=",
      "url": "_framework/System.Security.Cryptography.2zkzja4hey.wasm"
    },
    {
      "hash": "sha256-krG2PeUvZ7EJPXeqWAwDcSiEU6UVxqhXhDy+W5P6zno=",
      "url": "_framework/System.Text.Encodings.Web.6np35ac75v.wasm"
    },
    {
      "hash": "sha256-/RlE3/L8fPKGdbOglo8i0ug5xWfHIs8Im/HHs+NTVLU=",
      "url": "_framework/System.Text.Json.jcgtmeex5g.wasm"
    },
    {
      "hash": "sha256-sFPR2VdnZx1MTS014BkLf0jIDe/RKZenriNEtdsPFQA=",
      "url": "_framework/System.Text.RegularExpressions.c5nymhfkh4.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-wOxu8RAF1UrP44AicECCDoYcoFEeP0BYiYSkz2aySTo=",
      "url": "_framework/dotnet.0c1y88ndf9.js"
    },
    {
      "hash": "sha256-LticvV0K1JWalF6ABY1TwyDqsIJhV6EqHvq9XPO6lNo=",
      "url": "_framework/dotnet.native.iwghwm49ku.wasm"
    },
    {
      "hash": "sha256-TOSqY1b9vsdKZIcajDhve68SxAMowD6ImZXeApYkPNU=",
      "url": "_framework/dotnet.native.soli2tluij.js"
    },
    {
      "hash": "sha256-SOUHEQ3FhDAibBSR2u90NWZpoBjPuWRmH0BAATUlhJU=",
      "url": "_framework/dotnet.runtime.web2r9gqbh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-W81W5BcJjNFZsHgEWQ4WOJ0jVQQ5OnC7zZupDv4T+Fo=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-gSQrFYQVeWO+W9T34lrZQkOgNu9pySjxmz7NWo+MltY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-SiIVMGgRhdXjKSTIddX7mh9IbOXVcwQWc7/p4nS6D/0=",
      "url": "css/bootstrap.min.css"
    },
    {
      "hash": "sha256-C6CdrKvS/vt1S2Ll/R3olir/SOXif9zPjwbtFwt8364=",
      "url": "css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-xhLxCDVSQ665CQgFQFjddtFlhk3QmjxRet/vlLooc+k=",
      "url": "css/bracket.css"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-vxd4C1LzleBgW8qP0cUg/qaX0pvcLqfTcp7b2mpvNLI=",
      "url": "img/user.jpg"
    },
    {
      "hash": "sha256-W5EwgGd1RM7rJgO07nWYFNa69KVA0noft8WpLoMXAOc=",
      "url": "index.html"
    },
    {
      "hash": "sha256-HaVhkYisV7K/R15uM20MHzLrqbqTJc7oMRFSm6poz5E=",
      "url": "manifest.webmanifest"
    }
  ]
};
